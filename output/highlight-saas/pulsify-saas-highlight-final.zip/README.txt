Pulsify SaaS highlight, final set (13 slides, 1080x1920).
slides/ : 01-08 and 10-13 in order.
Slide 09 is your own phone video: record it from slide-9-script.md and place it between 08 and 10.
alternates/ : two other slide 5 versions (not in the set).
copy-and-style.md : final copy for every slide.
Illustrative numbers on slides 8, 11 and 12 are not client results.
